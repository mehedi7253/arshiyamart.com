@extends('layouts.temp2.master2')
@section('content')
	@include('layouts.temp2.nav')

	<section id="aa-myaccount" style="margin-top:0px;">

		<div class="container"  style="width:90%; margin-top:50px; margin:auto;">
		    
		    
		    <?php
		    if(isset($_GET['earn_id']))
		    {
		                  $session_u_id = Auth::user()->id;
		                  $session_a = Auth::user()->joining_amount;
        $today=date('Y-m-d');

		        $count=DB::table('ac_main')->whereDate('created_at',$today)->where('remark',"Daily_Earning")->where('user_id',$session_u_id)->count();
		        if($count >0 ){
		            
		            
		            echo '
		        <div class="control-group">
									 <div class="controls">
											 <div class="alert alert-success">

													 <strong style="color:#000">আপনার  Daily Earning পেতে অনুগ্রহ করে ২৪ঘন্টা অপেক্ষা করুন </strong>

											 </div>
										 </div>
							 </div>';
		           
							 
							 
		    }else
		    {
		        if($session_u_id>1680){
		        if($session_a <1501){
		        
		         DB::table('ac_main')->insert([
                                                                                      'user_id'         => $session_u_id,
                                                                                      'amount'          => 10,
                                                                                      'remark'          => "Daily_Earning",
                                                                                      'sender_number'   => 0,
                                                                                      'status'          => 1,
                                                                                 
                                                                                        ]);
		            
		            
		            
		            
		        echo '
		        <div class="control-group">
									 <div class="controls">
											 <div class="alert alert-success">

													 <strong style="color:#000" style="text-align:center">আপনার  ক্যাশ ওয়ালেটে ১০ টাকা জমা হয়েছে। </strong>

											 </div>
										 </div>
							 </div>';
		            
		        }
		        
		    }
		    }
		    }
		    
		    ;?>
		    
		    
		    
			@if (Session::has('message_success'))
							 <div class="control-group">
									 <div class="controls">
											 <div class="alert alert-success">

													 <strong style="color:#000">{{ session('message_success') }}</strong>

											 </div>
										 </div>
							 </div>
			 @endif
			 

		@if (Session::has('message_s'))
							 <div class="control-group">
									 <div class="controls">
											 <div class="alert alert-success">

													 <strong style="color:#000">{{ session('message_s') }}</strong>

											 </div>
										 </div>
							 </div>
			 @endif
			 


			 
			 
			 @if (Session::has('message_error'))
								<div class="control-group">
										<div class="controls">
												<div class="alert alert-danger">

														<strong style="color:#000">{{ session('message_error') }}</strong>

								 				</div>
											</div>
								</div>
				@endif 
				
				
				
				
				
		<?php
	$up_line_id=Auth::user()->up_line_id;
	$up_line_id_v=Auth::user()->trn;
	$up_line_id_vvv=Auth::user()->video;
	
	$ppppmersi=$up_line_id+$up_line_id_v;
	$my_id=Auth::user()->id;
	$auth_ran=Auth::user()->auth_ran;
	$mnnnnn=Auth::user()->name;
	
	$myiiidd=Auth::user()->j_mobile;
	$permission=Auth::user()->permission;
	$rank=Auth::user()->rank;
	
	;?>	
		
	
	<?php
	
	;?>    
	
<?php 
session_start();
    $_SESSION['s_ref']=""
;?>
		
		
		@if($my_id>1)		
				<?php
		
		      $user_id = Auth::user()->id;

		      $myshop= DB::table('shops')->where('owner_user_id',$user_id)->first();
		      @$shop_statu=$myshop->status;
?>
	@if(isset($myshop))	
		<p style="text-align:center"> My Shop Name is: {{ $myshop->shop_name}} <span style="color:red"> @if($myshop->status !=2) (Waiting for Approvel) <br>এপ্রুভ হওয়ার পর আপনি মার্সেন্ট ড্যাশবোর্ড দেখতে পাবেন @endif </span></p>
	@endif	
		
@if($shop_statu==2)
		<h3 style="text-align:center; color:blue;  border-raius:5px">Marchant Dashboard</h3>

				
		<div class="row" style="margin-bottom:50px; margin-top:20px">
				
				
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{url('/')}}/shoporder"> 
    				   	<div style="width:100%; padding: 30px 10px; background:red; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    					<span style="color:white">My Orders</span></div>
					</a>
				</div> 
				 
				
				
								<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{url('/')}}/shopproduct"> 
    				   	<div style="width:100%; padding: 30px 10px; background:blue; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-shopping-bag" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    					<span style="color:white">My Products</span></div>
					</a>
				</div>
				
				
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{url('/')}}/shopwallet"> 
    				   	<div style="width:100%; padding: 30px 10px; background:black; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-money" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    					<span style="color:white">Marchant Wallet</span></div>
					</a>
				</div>

					<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{url('/')}}/shopwithdraw"> 
    				   	<div style="width:100%; padding: 30px 10px; background:green; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-credit-card" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    					<span style="color:white">Withdraw</span></div>
					</a>
				</div>
				
				

</div>
<hr>
@endif
	
	
		
		
		
		
		
		
		
		 <?php
     /*
     $fsdf9fdf=DB::table('users')->get();
     foreach ($fsdf9fdf as $sid){
      $direct_count=DB::table('ac_join')->where('dr_id',$sid->id)->count();
                         if($direct_count >= 3){
                                                       DB::table('users')->where('id',$sid->id)->update([
                                                           'cbcm'=>1,
                                                           'cbcm_time'=>now()
                                                           ]);
                         }      
                        
    }
    */
    
    
    /*
    */
    
    ?>
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
			
		<h3 style="text-align:center; color:blue;  border-raius:5px">	{{$mnnnnn}} [ <i class="fa fa-gift" aria-hidden="true" style="color:red	"></i> ]</h3>
		<h4 style="text-align:center; color:red;  border-raius:5px; font-family: Arial, Helvetica, sans-serif;">	Shopping Dashboard</h4>
		
		
		
		
				
				
		<div class="row" style="margin-bottom:50px; margin-top:20px">
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{url('/')}}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:red; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    					<span style="color:white">Start Shopping</span></div>
					</a>
				</div>
				
				
				
				
				
					
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{url('/orders')}}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:green; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-list" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    					<span style="color:white">View my all orders</span></div>
					</a>
				</div>
				
				
				
						
					
			
				
				
				
				
				
				
				
				
				
			<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{url('/invite')}}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:pink; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-paper-plane" aria-hidden="true" style="font-size:50px; color:black; "></i><br>
    
    						<span style="color:black">Invite Friend  </span></div>
					</a>
				</div>	
			
			
			
			
			
			
			
			
			
		@if($up_line_id<1)			
			
			
			
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_l/?gnid=1') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:purple; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-money" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    					<span style="color:white">Wallet </span></div>
					</a>
				</div>		
			
								
					
				
			
			
					<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_w') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#DAF7A6; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-credit-card" aria-hidden="true" style="font-size:50px; color:blue;"></i><br>
    
    					<span style="color:blue">Withdraw</span></div>
					</a>
				</div>	
				
				
				
				
				
		@endif		
				
				
				
				
				
@endif
				
				
	
		
		<?php 
	$business_count=DB::table('shops')->where('owner_user_id',$my_id)->count();
	$m_prmi=DB::table('banners')->where('id',1010)->first();
	
	?>	
		
	@if($m_prmi->image == 1)
		
		
		
		
		
		
@if($business_count < 1)
					<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/createb') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#DAF7A6; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-briefcase" aria-hidden="true" style="font-size:50px; color:blue;"></i><br>
    
    					<span style="color:blue">Be a Merchant</span></div>
					</a>
				</div>			
		
@endif		
				
	@endif	
		
		
		
		
		
		
		
		
		
		
		
		
		
			
			
					
			</div>
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					<?php
					
					
					            $aa_usesfsdfsdfr=DB::table('ac_join')->where('user_id', $my_id)->where('status',1)->count();
					            $aa_usesfsderwerfsdfr=DB::table('ac_join')->where('user_id', $my_id)->where('trn', 1)->where('status',2)->count();
					            $aa_usesfsdsdfsdfderwerfsdfr=DB::table('ac_join')->where('user_id', $my_id)->where('trn','!=', 1)->where('status',2)->count();

					
					
					?>
					
					
						@if($aa_usesfsdfsdfr > 0)	
						<h2 style="text-align:center; border-radius:8px; background:yellow; color:black; width:80%; margin:auto">
						    <a href="/join/1"> Your Payment in Waiting for Approval </a>
						</h2>
						
						
						@endif
	
					
						@if($aa_usesfsderwerfsdfr > 0 )	
						
						    @if($up_line_id_v != 1)
						
						        <h2 style="text-align:center; border-radius:8px; background:green; color:white; width:80%; margin:auto">
						        <a href="/join/1"> Payment Arrpoved! Please Complete Your Joining... </a>
						        </h2>
                            @endif
						@endif
					
					
					
					
					
					
					
								@if($aa_usesfsdsdfsdfderwerfsdfr== 1)	
						
						    @if($rank < 1)
						
						        <h2 style="text-align:center; border-radius:8px; background:green; color:white; width:80%; margin:auto">
						        <a href="/join/1"> Payment Arrpoved! Please Complete Your Joining... </a>
						        </h2>
                            @endif
						@endif
								
					
					
					
		
					
					
					
		@if($ppppmersi > 0)		
		
		<hr>
		
		

		 <?php
    				       $auth_id=Auth::user()->id;
    				       //$my_count=14348907;
    				       $my_count=DB::table('ac_main')->where('user_id',$auth_id)->where('remark',"CBCM Commission")->count();
    				       $my_countttt=DB::table('users')->where('id',$auth_id)->first();
    				       
    				       
    				       ;?>
		
		<h3 style="text-align:center; color:blue;  border-raius:5px">	Team Dashboard  <span style="color:red"> [CBCM: 
		
		<?php
		
		$club=3;
		if($my_count > $club *3 *3*3*3*3*3*3*3*3*3*3*3*3*3){
		    echo '15th';
		    
		}
		elseif($my_count > $club *3 *3*3*3*3*3*3*3*3*3*3*3*3){
		    echo '14th';		    
		}
			elseif($my_count > $club *3 *3*3*3*3*3*3*3*3*3*3*3){
		    echo '13th';		    
		}
		elseif($my_count > $club *3 *3*3*3*3*3*3*3*3*3*3){
		    echo '12th';		    
		}
		elseif($my_count > $club *3 *3*3*3*3*3*3*3*3*3){
		    echo '11th';		    
		}				
		elseif($my_count > $club *3 *3*3*3*3*3*3*3*3){
		    echo '10th';		    
		}
		
		elseif($my_count > $club *3 *3*3*3*3*3*3*3){
		    echo '9th';		    
		}		
		
		elseif($my_count > $club *3 *3*3*3*3*3*3){
		    echo '8th';		    
		}
		
		
		elseif($my_count > $club *3 *3*3*3*3*3){
		    echo '7th';		    
		}		
		
		
		elseif($my_count > $club *3 *3*3*3*3){
		    echo '6th';		    
		}		
		
		elseif($my_count > $club *3 *3*3*3){
		    echo '5th';		    
		}		
		
		elseif($my_count > $club *3 *3*3){
		    echo '4th';		    
		}		
		
			elseif($my_count > $club *3 *3){
		    echo '3rd';		    
		}	
			elseif($my_count > $club*3 ){
		    echo '2nd';		    
		}
		
			elseif($my_count >3){
		    echo '2nd';		    
		}
		
		
			elseif($my_count == 3){
		    echo '1st';		    
		}
		
		
		
			elseif($my_count < $club){
			    
			       if($my_countttt->cbcm != 1){
			           
			        		    echo 'আপনি এখনো কোন   বোর্ডের  অন্তর্ভুক্ত হননি';	

			    }else{
			        	        echo '1st';	
			    }
			    
		    
		}
		
		
		?>
		
		
		]</span> </h3>
		<h4 style="text-align:center; color:red;  border-raius:5px; font-family: Arial, Helvetica, sans-serif;">	My ID: {{$myiiidd}} 			        (Authorized Code: 8820{{$my_id}})</h4>
		
		<div class="row" style="margin-bottom:50px; margin-top:20px">
				
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="#"> 
    				   	<div style="width:100%; padding: 30px 10px; background:silver; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-user" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    				    
    						<span style="color:white; ">View My Profile</span></div>
					</a>
				</div>	
				
				
				<?php
		    
		                  $session_u_id = Auth::user()->id;
		                  $session_a= Auth::user()->joining_amount;
		        ?>
				
				
			@if($session_u_id > 1680)
		        @if($session_a < 1501)	
					
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/class') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:red; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-money" aria-hidden="true" style="font-size:50px; color:white;"></i><br>
    
    					<span style="color:white">Daily Earning</span></div>
					</a>
				</div>	
				@endif
				@endif
				
				
			@if($up_line_id_vvv == 1)			
				
				
				
				@endif
				
					<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_generation') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:red; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-users" aria-hidden="true" style="font-size:50px; color:white;"></i><br>
    
    					<span style="color:white">My Team</span></div>
					</a>
				</div>	
				
				
<!--				
				<div class="col-md-3" style="margin-top:5px">
    				   	<div style="width:100%; padding: 20px 8px; background:BLUE; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        



                @if($up_line_id_v > 0)	
    				   	
    				   	<a href="{{ url('/my_generation') }}?tree=1" style="border:2px solid white; border-radius:8px; padding:10px"> 
    				    <span style="color:white; "> <i class="fa fa-users" aria-hidden="true" style="font-size:20px; color:white; "></i>
    				    My Tree </span>
    				    </a>
    				   
    				   
    			@endif		   
    				   @if($up_line_id_v > 0)
    				   <br><br>
    					@endif   
    				   
    				   
    	    	@if($up_line_id > 0)		   
    				   
                    	<a href="{{ url('/my_generation') }}" style="border:2px solid white; border-radius:8px; padding:10px"> 
	                    <span style="color:white; "><i class="fa fa-users" aria-hidden="true" style="font-size:20px; color:white; "></i>	My Sales Team </span>
    				    </a>
    		@endif		    
    				    
    				    
    				    
    				   </div>
    				   
				</div>-->
				
				
		
		<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_l') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#ff00bf; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-money" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">My Wallet Ledger </span></div>
					</a>
				</div>	
				
		
		
		
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_w') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:GREEN; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-credit-card" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    					<span style="color:white; ">Withdraw</span></div>
					</a>
				</div>		
				
				
				
				
						
					
					
	

				
		<!--		
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_g') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#ff0080; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-gift" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">Buy Gift Card</span></div>
					</a>
				</div>	
				
					-->
					
					
					
				<div class="col-md-3" style="margin-top:5px" data-toggle="modal" data-target="#modal-lg">
				   	
    				   	<div style="width:100%; padding: 5px 5px; background:green; font-size:100%; color:black; border-radius:8px;text-align:center">
    				       
    				       <?php
    				       $auth_id=Auth::user()->id;
    				       $my_bdt=DB::table('ac_join_rccc')->where('user_id',$auth_id)->where('status',2)->sum('amount');
    				       ;?>
    				        <h5 style="color:white;">BDT:  {{$my_bdt}}</h5><br>
    				        <i class="fa fa-plus" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; "> Add Fund </span></div>
					
				</div>	
						
	
	
	
	
	
	                   
                

   <div class="modal fade" id="modal-lg" style="z-index:999999">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">

              <div class="modal-body">


<div class="row" style="margin-bottom:100px">

					<div class="col-md-12">


<?php

$results12 = DB::select('select * from banners where id = :id', ['id' => 12]);
$results13 = DB::select('select * from banners where id = :id', ['id' => 13]); 
$results14 = DB::select('select * from banners where id = :id', ['id' => 14]);

;?>


   @foreach($results12 as $t12)
     <?php 
        $bkash=$t12->image;   
        
     ;?>
@endforeach










@foreach($results13 as $t13)
     <?php 
        $rocket=$t13->image;     
     ;?>
@endforeach

@foreach($results14 as $t14)
     <?php 
        $nagad=$t14->image;     
     ;?>
@endforeach





 <div>


<span style="color:blue"><b>পেমেন্ট পদ্ধতিঃ </b><br></span>
বিকাশ নম্বর: {{$bkash}} (পার্সনাল)।<br>
রকেট নম্বর: {{$rocket}} (পার্সনাল)।<br>
নগদ নম্বর: {{$nagad}} (পার্সনাল)।<br>
ব্যাংক এ্যাকাউন্ট নম্বর: 111-222-333-4444 (এ্যাকাউন্টের নাম: Cash Baba Online Shop, ব্যাংক: ডাচ বাংলা ব্যাংক)<br>
<span style="color:red">উল্লেখিত নম্বরে আপনার  কাঙ্খিত টাকার পরিমাণ পরিশোধ করতে হবে। <br></span>

<span style="color:blue"><b>নোটঃ </b><br></span>
বিকাশ/রকেট/নগদে পে করলে নিচের বক্স TrxID লিখুন। যদি ক্যাশ পেমেন্ট হয়, তাহলে প্রাপ্ত মানি রিসিপ্ট নম্বর লিখতে হবে ও  ব্যাংক পেমেন্ট হয় তাহলে টাকা প্রদানের স্লিপ নম্বর লিখতে হবে। 
					        
					    </div>









<div class="aa-myaccount-register" style="background:#EAEDED; padding:10px; border-radius:8px; margin-top:10px">



			<form id="account_Form" class="aa-login-form" name="accountForm" action="{{ url('/my_ggbdt') }}" method="post">
<!--			<form id="account_Form" class="aa-login-form" name="accountForm" action="{{ url('/joining_payment') }}" method="post">
-->								@csrf
	
	
															
							
	<h3 style="color:blue; text-align:center">Payment Information:</h3>	



    	<input name="amount" type="number"  placeholder=" Amount" min="200" required="" >	<br><br>


<select name="payment_method" style="width:100%; padding:6px;" required>
                       <option value="">Payment Method</option>

        <option value="bKash">bKash</option>
        <option value="Rockate">Rockate</option>
        <option value="Nagod">Nagod</option>
        <option value="Bank_Payment">Bank Payment</option>
        
        <option value="Cash_Payment">Cash Payment</option>
        
        
</select>
<br><br>

    	<input name="package" type="hidden"  placeholder="Sender Number" style="width:100%" value="">	





<label> TrxID:  (বিকা-রকেট-নগদ এ পে করার পর SMS এ যে TrxID পেযেছেন)</label><br>


    	<input name="trx_id" type="text"  placeholder="TrxID/Money Recpt Number"  required="" >	<br>
			
			


<label> যে নম্বর থেকে পে করেছেন (শুধু  মাত্র বিকাশ/রকেট/নগদের জন্য)</label><br>
    	<input name="sender_number" type="number"  placeholder="Sender Number" style="width:100%" minlength="11">	
			



<button type="submit" class="btn btn-default" style="width:100%; background:silver; font-size:130%">Confirm & Submit</button>
							</form>



</div>
        



       
</div>


</div>
                  
                  
    

              </div>
              <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="my_w_mobile"> 
    				   	<div style="width:100%; padding: 30px 10px; background:green; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-exchange" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">Fund Transfer</span></div>
					</a>
				</div>	
							
	
	
				
					
			<!--
					<div class="col-md-3" style="margin-top:5px">
				   	<a href="#"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#9900cc; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-clock-o" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">Transuction History</span></div>
					</a>
				</div>
				
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="#"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#9900cc; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-clock-o" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">Transuction History</span></div>
					</a>
				</div>	-->						
						<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_r') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#00ff00; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-retweet" aria-hidden="true" style="font-size:50px; color:black; "></i><br>
    
    						<span style="color:black; ">Product Re-Purchase</span></div>
					</a>
				</div>		
					
					


				 <?php
            $my_id=Auth::user()->id;
            $c_amount=DB::table('ac_mobile_wallet')->where('user_id',$my_id)->sum('amount');
            ?>    

		<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/join2bdt_mobile') }}/{{$my_id}}"> 
    				   	<div style="width:100%; padding: 10px 10px; background:red; font-size:100%; color:white; border-radius:8px;text-align:center">
    				        
    				         <?php
    				       $auth_id=Auth::user()->id;
    				       $my_bdt=DB::table('ac_mobile_wallet')->where('user_id',$auth_id)->sum('amount');
    				       ;?>
    				        <h5 style="color:white;">Balance:  {{$my_bdt}}</h5><br>

    				        <i class="fa fa-mobile" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">Mobile Re-Charge</span></div>
					</a>
				</div>		
					




					
					
					
					
					
					
			</div>			
			
			
			


@endif		
		
		
		
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
					
						
				
	@if($up_line_id>1)		
	<!--	
		<hr>
		
		

		
		
		<h3 style="text-align:center; color:blue;  border-raius:5px">	Team Dashboard </h3>
		<h4 style="text-align:center; color:red;  border-raius:5px; font-family: Arial, Helvetica, sans-serif;">	My ID: {{$myiiidd}} 			        (Authorized Code: 8820{{$my_id}})</h4>
		
		<div class="row" style="margin-bottom:50px; margin-top:20px">
				
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="#"> 
    				   	<div style="width:100%; padding: 30px 10px; background:red; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-user" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    				    
    						<span style="color:white; ">View My Profile</span></div>
					</a>
				</div>	
					
				
				
				
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_generation') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:BLUE; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-users" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    				<span style="color:white; ">	My Sales Team </span></div>
					</a>
				</div>
				
				
		
		<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_l') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#ff00bf; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-money" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">My Wallet Ledger </span></div>
					</a>
				</div>	
				
		
		
		
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_w') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:GREEN; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-credit-card" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    					<span style="color:white; ">Withdraw</span></div>
					</a>
				</div>		
				
				
				
				
						
					
					
	

				
				
						<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_g') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#ff0080; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-gift" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">Buy Gift Card</span></div>
					</a>
				</div>	
				
					
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="#"> 
    				   	<div style="width:100%; padding: 30px 10px; background:green; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-exchange" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">Fund Transfer</span></div>
					</a>
				</div>	
						
				
			
				
				
				
				
				<div class="col-md-3" style="margin-top:5px">
				   	<a href="#"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#9900cc; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-clock-o" aria-hidden="true" style="font-size:50px; color:white; "></i><br>
    
    						<span style="color:white; ">Transuction History</span></div>
					</a>
				</div>							
							<div class="col-md-3" style="margin-top:5px">
				   	<a href="{{ url('/my_r') }}"> 
    				   	<div style="width:100%; padding: 30px 10px; background:#00ff00; font-size:120%; color:black; border-radius:8px;text-align:center">
    				        
    				        <i class="fa fa-upload" aria-hidden="true" style="font-size:50px; color:black; "></i><br>
    
    						<span style="color:black; ">Product Re-Purchase</span></div>
					</a>
				</div>		
					
					
					
					
					
					
					
					
					
			</div>			
			
			
			-->


@endif		
		
		
		
		
				
				
				
				
				
				
				
				
				
		
			<div class="row" style="margin-bottom:100px">

					<div class="col-md-6">
						<div class="aa-myaccount-register" style="background:#EAEDED; padding:10px; border-radius:8px; margin-top:10px">

						<h3 style="color:red">Update shopping account</h3>
							<form id="account_Form" class="aa-login-form" name="accountForm" action="{{ url('/my-account') }}" method="post">
								@csrf
								<input name="name" type="text"  value="{{ $user_details->name }}" placeholder="Name">
								<input type="email" value="{{ $user_details->email }}" required=""/>
								<input type="text" name="address" value="{{ $user_details->address }}" placeholder="Adress">
					
								<input type="text" name="mobile" value="{{ $user_details->phone }}" placeholder="Mobile">
								<button type="submit" class="btn btn-default" style="width:100%; background:silver">Update Profile</button>
							</form>
					</div><!--/login form-->
				</div>

				<div class="col-md-6">
					<div class="aa-myaccount-login" style="background:#EAEDED; padding:10px; border-radius:8px; margin-top:10px; margin-top:70px">
						<h3 style="color:red">Change login Password</h3>
					<form id="passwordForm" name="passwordForm" class="aa-login-form" action="{{ url('/update-user-pwd') }}" method="POST">
						@csrf
						<input type="password" name="current_pwd" id="current_pwd" placeholder="Current Password">
						<span id="chkPwd"></span>
						<input type="password" name="new_pwd" id="new_pwd" placeholder="New Password">
						<input type="password" name="confirm_pwd" id="confirm_pwd" placeholder="Confirm Password">
						<button type="submit" class="btn btn-default" style="width:100%; background:silver">Update</button>
					</form>
				</div>
			</div>
			
			
			</div>
			
		
		
		
		

@if($permission==1)	

@if($rank < 1)


<!--		
			<div class="row" style="padding:20px;">
				<div class="col-md-4 col-md-offset-4">
<h5 style="text-align:center">
						<a href="{{ url('/join') }}/join?pp=1"  style="font-size:150%; color:red; text-align:center">
						    

						    Add a person to my Team 

						    

		    
						    
						    </a></h5>

<a href="{{ url('/join') }}/join?pp=1"><img src="{{ url('/assets/ew.gif') }}" style="width:95%; text-align:center"/></a>
				</div>
			</div>
-->
@endif
@endif







@if($rank >= 1)


		
<!--			<div class="row" style="padding:20px;">
				<div class="col-md-4 col-md-offset-4">
<h5 style="text-align:center" >
						<a href="{{ url('/join') }}/tt/?pp=1"  style="font-size:150%; color:white; text-align:center; background:green; border: 1px solid black; border-radius:8px; padding:20px">
						    

						    Add member to my Team 

						    

		    
						    
						    </a></h5>

				</div>
			</div>-->

@endif














			
			
			
		</div>








	</section>


@endsection
