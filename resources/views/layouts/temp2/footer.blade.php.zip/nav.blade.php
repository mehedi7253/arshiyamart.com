 <?php
 
 
$results7 = DB::select('select * from banners where id = :id', ['id' => 7]);




 
    ;?>         
          
 
    
 
@foreach($results7 as $t7) 
     <?php 
        $image7=$t7->image;     
     ;?>
@endforeach








<style>
 

#navbar {
  background-color:#D4E6F1;
  position: fixed;
  top: 0;
  width: 100%;
  display: block;
  transition: top 0.3s;
 
}

#navbar a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 0px;
  text-decoration: none;
  font-size: 17px;
   color:black;
}

#navbar a:hover {
  background-color: #ddd;
  color: black;
}
</style>





<div class="com_add">
    

                
     <div style="height:40px; width:100%; top:0; position:fixed; float:left; z-index:19999; border:2px solid white;  border:0px;">
         
         
<div style="height:40px; width:100%; ; float:left; z-index:199999; border:2px solid white;  border:0px; display:block" >
         
<div id="navbar" style="float:left; width:100%">
    
    <div style="float:left; width:80%">
 <?php
 $h99=DB::table('banners')->where('id',9)->first();
 $h10=DB::table('banners')->where('id',10)->first();
 
$h9=$h99->image;
$tags = explode(',',$h9);

foreach($tags as $key) {    
    echo '<a href="tel:'.$key.'"><p style="margin-left:5px; color:black"><span class="fa fa-phone"></span> '.$key.' </p></a>';     
}
?>



  <a href="{{$h10->image}}" style="margin-left:5px">
  <i class="fa fa-envelope" aria-hidden="true"></i>  {{$h10->image}} 
</a>


<!--  <a href="#" style="color:blue"><i class="fa fa-shopping-bag" aria-hidden="true" style="color:blue"></i>
 ম্যাচেন্ট প্যানেল</a>
  <a href="#" style="color:blue"><i class="fa fa-user" aria-hidden="true" style="color:blue"></i>
      ইউজার প্যানেল</a>
  <a href="#" style="color:blue"><i class="fa fa-money" aria-hidden="true" style="color:blue"></i>
      এ্যাফেলিয়েট প্যানেল--></a>






</div>

  
  <div style="width:20%; float:right">
    
  

                      
                                         
                                         
<?php 
	$ficon=DB::table('banners')->where('id',41)->first();
	$app_icon=DB::table('banners')->where('id',30)->first();
	
	?>	
	
	
  <a href="{{ $ficon->image }}" target="_blank"><span class="fa fa-facebook-official" style="color:blue; font-size:160%"></span></a>
                      	
                                         
                                        

<a href="{{ $app_icon->image }}" target="_blank" style="margin-left:20px"><span class="fa fa-android" style="color:blue; font-size:160%"></span></a>
  
  
  
</div>
  </div>
  
</div>


 




 <section id="menu"style="padding:5px; height:50px" >
    

           
             <a href="#" style="float:left; margin-top:8px; margin-left:5px"> 
                <span id="sidebarCollapse2" style="color:white; display:black;  padding:50px 4px";>
                                <i class="fa fa-bars" aria-hidden="true" ></i>
                                <span>Menu</span>
                            </span>
            
            </a>
            
            
            
            
            
            
                <a href=" {{url('/')}} "><img src="{{url('/')}}/assets/admin/img/banners/<?php echo $image7;?>" alt="logo img" style="float:left; margin-left:20px; height: 40px; border-radius:4px"></a>
                
                
                
                
           
            
             <div style="float:left; width:35%; margin-left:100px">
                <form action="{{ url('/search') }}" method="post">
                    
                                        @csrf

                  <input type="text" name="search" id="" placeholder="Search product (Name)" required="" style="height:39px; width:70%; border-radius:4px; background:white;  border: 1px solid #ccc;
">
                  <button type="submit" style="height:40px; margin-left:-5px"><span class="fa fa-search" style="padding: 0px 10px"></span></button>
                </form>
              </div>
            
            
                        
              <div style="float:left; width:auto; margin-top:5px; padding:5px;  margin-left:4px">
               <a href="{{url('/')}}/news" style="color:white"><i class="fa fa-commenting" aria-hidden="true"></i> Review </a>
                </div>
            
            
                   <div style="float:left; width:auto; margin-top:5px; padding:5px;  margin-left:4px; font-size:110%">
               <a href="{{url('/')}}/offer?camping=1" style="color:white"><i class="fa fa-bullhorn" aria-hidden="true"></i> Campaigns
 </a>
                </div>
                   
            
            
            <div  style="float:right; margin-top:5px; padding:5px; margin-right:50px" >
                <ul class="aa-head-top-nav-right">
                  <!-- <li class="hidden-xs"><a href="{{ url('/cart') }}">My Cart</a></li> -->
                  

<style>
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #f9f9f9;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
  
}

.dropdown:hover .dropdown-content {
  display: block;
}
</style>



<div class="#" style="float:left">
                  @if (empty(Auth::check()))
                  
                  
                  
                  <div><a href="/login-registerj" style="color:white"> <i class="fa fa-lock" aria-hidden="true" style="color:white"></i>
 Login </a></div>
 
 @endif
 </div>


<div class="#" style="float:right">
                    @if (empty(Auth::check()))
                  
            <div><a href="/login-register" style="color:white"> <i class="fa fa-user" aria-hidden="true" style="color:white"></i>
 Register </a></div>
 
                  
 
 @endif
 </div>







<div class="dropdown" style="float:right; margin-left:18px">
                  @if (empty(Auth::check()))
                  
        
                  
                  
                 
                  @else
                  <li><a href=""style="color:white"><i class="fa fa-user" aria-hidden="true" style="color:white"></i> My Account</a></li>
                  @endif
  
  
  
  
  
  
  
  
   @if (empty(Auth::check()))
  
  <div class="dropdown-content" style="margin-right:100px;">
  <a href="{{ url('/login-registerj') }}"><p> Login</p></a>
  <a href="{{ url('/login-register') }}"><p> Signup</p></a>

 
  
</div>
   @else




  <div class="dropdown-content" style="margin-right:100px;">
<a href="{{ url('/my-account') }}"><p> My Profile</p> </a>
<a href="{{ url('/logout') }}"> <p>  Logout</p> </a>


</div>






@endif

</div>





                </ul>
              </div>
            
    
  </section>
  </div>
  
  </div>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
 
<div class="mob_add">
     <div style="height:50px; width:100%; top:0; position:fixed; float:left; z-index:19999; border:2px solid white;  border:0px;">

 <section id="menu"style="padding:5px" >
    
    
    
<div style="float:left;  width:20%;">
           
             <a href="#" style="float:left; margin-top:4px; margin-left:5px"> 
                <span id="sidebarCollapse22" style="color:white; display:black; padding:50px 4px";>
                                <i class="fa fa-bars" aria-hidden="true" ></i>
                                <span>Menu</span>
                            </span>
            
            </a>
            
 </div>          
            
             
            
               
 <div style="float:left;  width:60%;  text-align:center;">
                             <a href=" {{url('/')}} "><img src="{{url('/')}}/assets/admin/img/banners/<?php echo $image7;?>" alt="logo img" style="text-align:center; height: 30px; max-width:120%; border-radius:4px"></a>

                 
</div>
            
           
            
                 
   <div style="float:left;  width:20%;">         
   
   

       <i class="fa fa-search" onclick="myFunction()" aria-hidden="true" style="font-size:150%; color:white; padding:5px"></i>
  
                                  

      <a href="/cart">
                 
                 <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:150%; color:white; padding:5px"></i>
                 
     </a>            

                 
                 
            <!--    <form action="{{ url('/search') }}" method="post" style="float:right;margin-right:5px; ">
                    
                                       

               <input type="text" name="search" id="" placeholder="Search product" required="" style="height:27px; width:72%; border-radius:2px; background:white;  border: 1px solid #ccc;
">
                  <button type="submit" style="height:28px; margin-left:-5px"><span class="fa fa-search" style="padding: 0px 0px"></span></button>
                </form>-->
           
            
            

            
                                                
</div>
            
            
         <hr>
 <div id="myDIV" style="width:100%;  text-align:center; display:none;">
  
  <form action="{{ url('/search') }}" method="post">
       @csrf
   <div class="search" style="width:100%">
      <input  name="search" type="text" class="searchTerm" placeholder="  Search product here..">
      <button type="submit" class="searchButton">
        <i class="fa fa-search"></i>
     </button>
   </div>
   </form>
   
</div>           
    
    
    
    <script>
function myFunction() {
  var x = document.getElementById("myDIV");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>
    
    
    
    
    
    
    
    
  </section>
  
  
  

  
  
  

  
  </div> 
  
  
 
  
   
  </div>
  
  
  
  
  
  
  
  </div>