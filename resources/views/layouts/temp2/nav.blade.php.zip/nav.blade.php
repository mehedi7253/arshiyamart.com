 <?php
 
 
$results7 = DB::select('select * from banners where id = :id', ['id' => 7]);





    ;?>         
          



@foreach($results7 as $t7)
     <?php 
        $image7=$t7->image;     
     ;?>
@endforeach













<div class="com_add">
     <div style="height:40px; width:100%; top:0; position:fixed; float:left; z-index:19999; border:2px solid white;  border:0px;">

 <section id="menu"style="padding:5px" >
    
                                     <a href=" {{url('/')}} "><img src="{{url('/')}}/assets/admin/img/banners/<?php echo $image7;?>" alt="logo img" style="float:left; height: 40px; border-radius:4px"></a>

           
             <a href="#" style="float:left; margin-top:8px; margin-left:5px"> 
                <span id="sidebarCollapse2" style="color:white; display:black;  padding:50px 4px";>
                                <i class="fa fa-bars" aria-hidden="true" ></i>
                                <span>Menu</span>
                            </span>
            
            </a>
            
            
            
            
           
            
             <div style="float:left; width:50%; margin-left:100px">
                <form action="{{ url('/search') }}" method="post">
                    
                                        @csrf

                  <input type="text" name="search" id="" placeholder="Search product (Name)" required="" style="height:39px; width:70%; border-radius:4px; background:white;  border: 1px solid #ccc;
">
                  <button type="submit" style="height:40px; margin-left:-5px"><span class="fa fa-search" style="padding: 0px 10px"></span></button>
                </form>
              </div>
            
            
                        
              <div style="float:left; width:auto; margin-top:5px; padding:5px;  margin-left:4px">
               <a href="{{url('/')}}/news" style="color:white">Comments/Review </a>
                </div>
            
            
            
            
            
            <div  style="float:right; margin-top:5px; padding:5px; margin-right:50px" >
                <ul class="aa-head-top-nav-right">
                  <!-- <li class="hidden-xs"><a href="{{ url('/cart') }}">My Cart</a></li> -->
                  

<style>
.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: white;
  width: 400px;
  height:700px;
  margin-left:-100px;
  
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  padding: 12px 16px;
  z-index: 1;
  
}

.dropdown:hover .dropdown-content {
  display: block;
}
</style>



<div class="#" style="float:left">
                  @if (empty(Auth::check()))
                  
                  
                  
                  <div><a href="/login-registerj" style="color:white"> <i class="fa fa-lock" aria-hidden="true" style="color:white"></i>
 Login </a></div>
 
 @endif
 </div>


<div class="#" style="float:right">
                    @if (empty(Auth::check()))
                  
            <div><a href="/login-register" style="color:white"> <i class="fa fa-user" aria-hidden="true" style="color:white"></i>
 Register </a></div>
 
                  
 
 @endif
 </div>







<div class="dropdown" style="float:right; margin-left:18px">
                  @if (empty(Auth::check()))
                  
        
                  
                  
                 
                  @else
                  <li><a href="#"style="color:white"><i class="fa fa-user" aria-hidden="true" style="color:white"></i> My Account</a></li>
                  @endif
  
  
  
  
  
  
  
  
   @if (empty(Auth::check()))
  
  <div class="dropdown-content" style="margin-right:100px;">
  <a href="{{ url('/login-registerj') }}"><p> Login</p></a>
  <a href="{{ url('/login-register') }}"><p> Signup</p></a>

 
  
</div>
   @else




<div class="dropdown-content" style="margin-right:100px; width:300px;  overflow-y: scroll;">
<!--<a href="{{ url('/my-account') }}"><p> My Profile</p> </a>
<a href="{{ url('/logout') }}"> <p>  Logout</p> </a>

-->


<div style="margin-right:200px; width:300px; barkground:red">


  
    <a href="/my-account" class="w3-bar-item w3-button">
      <i class="fa fa-user" aria-hidden="true" style="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; My Profile</a>
      	
  
  
  <a href="/" class="w3-bar-item w3-button">
      <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; View Shopping</a>
      	
      	
  <a href="/orders" class="w3-bar-item w3-button">
      <i class="fa fa-shopping-bag" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; 
      View orders</a>
      
      
      
      
      
            <?php
                      $au_user=Auth::user()->id;
                      $total_allr=DB::table("users")->where('upline_arry', 'like', '%'.$au_user.'%')->count();



?>  
      
      
  <a href="/my_generation" class="w3-bar-item w3-button">  <i class="fa fa-users" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; My Team <span style="color:blue">({{$total_allr}})</span></a>
      	
    
    
    
      	<?php
      	 $main_w=Auth::user()->id;
      	$total_cash_wallet_w=DB::table("ac_main")->where('user_id', $main_w)->sum("amount");
      	?>  	
      	
      	
<!--    <a href="/my_l" class="w3-bar-item w3-button">  <i class="fa fa-money" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp;My Wallet <span style="color:blue"> ({{$total_cash_wallet_w}})</span></a>-->
      	
      	
      	
      	
      	


    	
      	
      	
      	
         	<?php
      	 $main_w=Auth::user()->id;
      	$total_shop_wallet_r1=DB::table("ac_shop")->where('user_id', $main_w)->where('remark', 0)->sum("amount");
      	$total_shop_wallet_r2=DB::table("ac_main")->where('user_id', $main_w)->where('remark', 0)->sum("amount");
      	?>    	
      	
  <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Referral Bonus <span style="color:blue">({{$total_shop_wallet_r1+$total_shop_wallet_r2}})</span></a>
      	     	
      	
      	
      	
      	
             	<?php
      	 $main_w=Auth::user()->id;
      	$total_shop_wallet_r1b=DB::table("ac_shop")->where('user_id', $main_w)->where('remark','>','0')->where('remark','<','11')->sum("amount");
      	$total_shop_wallet_r2b=DB::table("ac_main")->where('user_id', $main_w)->where('remark','>','0')->where('remark','<','11')->sum("amount");
      	?>      	
      	
      	
    <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Genenation Bonus <span style="color:blue">({{$total_shop_wallet_r1b+$total_shop_wallet_r2b}})</span></a>
      	
      	
      	
<!--    	Sales Bonus=15 !-->
      	
                	<?php
      	 $main_w=Auth::user()->id;
      	$total_shop_wallet_r15=DB::table("ac_shop")->where('user_id', $main_w)->where('remark',15)->sum("amount");
      	$total_shop_wallet_r25=DB::table("ac_main")->where('user_id', $main_w)->where('remark',15)->sum("amount");
      	?>       	
      	
          <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Sales Bonus <span style="color:blue">({{$total_shop_wallet_r15+$total_shop_wallet_r25}})</span></a>
      		
      	
      
 <!--    	1% return Bonus=১00 !-->     
        <?php
      	$main_w=Auth::user()->id;
      	$total_shop_wallet_r100=DB::table("ac_shop")->where('user_id', $main_w)->where('remark',100)->sum("amount");
      	$total_shop_wallet_r200=DB::table("ac_main")->where('user_id', $main_w)->where('remark',100)->sum("amount");
      	?>     	
          	
          <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Daily Return<span style="color:blue">({{$total_shop_wallet_r100+$total_shop_wallet_r200}})</span></a>
      		  	
      	
      	
<!--    	Monthly Slary Bonus=16 !-->     
           <?php
      	$main_w=Auth::user()->id;
      	$total_shop_wallet_r16=DB::table("ac_shop")->where('user_id', $main_w)->where('remark',16)->sum("amount");
      	$total_shop_wallet_r26=DB::table("ac_main")->where('user_id', $main_w)->where('remark',16)->sum("amount");
      	?>     	
      	
           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Monthly Salary <span style="color:blue">({{$total_shop_wallet_r16+$total_shop_wallet_r16}})</span></a> 	
      	
    
           <?php
      	$main_w=Auth::user()->id;
      	$total_shop_wallet_r17=DB::table("ac_shop")->where('user_id', $main_w)->where('remark',17)->sum("amount");
      	$total_shop_wallet_r27=DB::table("ac_main")->where('user_id', $main_w)->where('remark',17)->sum("amount");
      	?>           	   	      	
           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Rank-Reward <span style="color:blue">({{$total_shop_wallet_r17+$total_shop_wallet_r17}})</span></a> 	    	     	
      	
      	
    	      	 
   <!--    	File Fund Bonus=18 !-->     
           <?php
      	$main_w=Auth::user()->id;
      	$total_shop_wallet_r18=DB::table("ac_shop")->where('user_id', $main_w)->where('remark',18)->sum("amount");
      	$total_shop_wallet_r28=DB::table("ac_main")->where('user_id', $main_w)->where('remark',18)->sum("amount");
      	?>      	
      	           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Life Fund <span style="color:blue">({{$total_shop_wallet_r18+$total_shop_wallet_r18}})</span></a> 	    	     	
      	
      	
      	
           	<?php
      	 $main_w=Auth::user()->id;
      	$total_shop_wallet_w=DB::table("ac_shop")->where('user_id', $main_w)->sum("amount");
      	?>   	
      	      	           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Shopping Balance <span style="color:red"> ( {{$total_shop_wallet_w}})</span></a> 		
      	
      	
      	
      	
      	
          	      	           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Total Cash Balance <span style="color:red">({{$total_cash_wallet_w}})</span></a> 	
      	  	
      	<br>
      	
        <a href="#" class="w3-bar-item w3-button" data-toggle="modal" data-target="#modal-lg">  <i class="fa fa-money" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp;Add Fund </a>
      	

      	
           	<br>	
      	
      	  <a href="/my_w_mobile" class="w3-bar-item w3-button">  <i class="fa fa-exchange" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Fund Transfar</a>
    
      	
      	
     	<br>
      	
      	

      	
      	
      	
      	      	
          	  <a href="/my_l" class="w3-bar-item w3-button">  <i class="fa fa-th-large" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Statment</a>	
      	
      	
           	<br>	
      	
      	
      	
 <a href="/my_w" class="w3-bar-item w3-button">  <i class="fa fa-credit-card" aria-hidden="true" sstyle="font-size:120%; color:blue; "></i>
      	&nbsp; 	&nbsp; Withdraw </a>
      	
      	
    
      	
     	<br>
      	
      	
     <a href="/my_generation" class="w3-bar-item w3-button">  <i class="fa fa-users" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; + New Registration</a>
      	
      	
      	
      	
      	
<!--      	
      	
  <a href="/my_w_mobile" class="w3-bar-item w3-button">  <i class="fa fa-exchange" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Fund Transfar</a>
      	
      	<br>
      	-->
     	<br>      	
      	
      

  <a href="/logout" class="w3-bar-item w3-button;" style="color:red">
      <i class="fa fa-sign-out" aria-hidden="true" style="font-size:120%; color:red; "></i>
      	&nbsp; 	&nbsp; Logout</a>
      	
      	
      	
      	<br>
      	<br>
      	<br>
      	
      	      	<br>
      	<br>
      	<br>
      	
      	
      	
      	
      	
      		
</div>




</div>



</div>





<div class="modal fade" id="modal-lg" style="z-index:999999; width:110%">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">

              <div class="modal-body">


<div class="row" style="margin-bottom:100px">

					<div class="col-md-12">


<?php

$results12 = DB::select('select * from banners where id = :id', ['id' => 12]);
$results13 = DB::select('select * from banners where id = :id', ['id' => 13]); 
$results14 = DB::select('select * from banners where id = :id', ['id' => 14]);

;?>


   @foreach($results12 as $t12)
     <?php 
        $bkash=$t12->image;   
        
     ;?>
@endforeach










@foreach($results13 as $t13)
     <?php 
        $rocket=$t13->image;     
     ;?>
@endforeach

@foreach($results14 as $t14)
     <?php 
        $nagad=$t14->image;     
     ;?>
@endforeach





 <div>


<span style="color:blue"><b>পেমেন্ট পদ্ধতিঃ </b><br></span>
বিকাশ নম্বর: {{$bkash}} (পার্সনাল)।<br>
রকেট নম্বর: {{$rocket}} (পার্সনাল)।<br>
নগদ নম্বর: {{$nagad}} (পার্সনাল)।<br>


<span style="color:blue"><b>নোটঃ </b><br></span>
বিকাশ/রকেট/নগদে পে করলে নিচের বক্স TrxID লিখুন। যদি ক্যাশ পেমেন্ট হয়, তাহলে প্রাপ্ত মানি রিসিপ্ট নম্বর লিখতে হবে।
					        
					    </div>









<div class="aa-myaccount-register" style="background:#EAEDED; padding:10px; border-radius:8px; margin-top:10px">



			<form id="account_Form" class="aa-login-form" name="accountForm" action="{{ url('/my_ggbdt') }}" method="post">
<!--			<form id="account_Form" class="aa-login-form" name="accountForm" action="{{ url('/joining_payment') }}" method="post">
-->								@csrf
	
	
															
							
	<h3 style="color:blue; text-align:center">Payment Information:</h3>	



    	<input name="amount" type="number"  placeholder=" Amount" min="200" required="" >	<br><br>


<select name="payment_method" style="width:100%; padding:6px;" required>
                       <option value="">Payment Method</option>

        <option value="bKash">bKash</option>
        <option value="Rockate">Rockate</option>
        <option value="Nagod">Nagod</option>
        <option value="Bank_Payment">Bank Payment</option>
        
        <option value="Cash_Payment">Cash Payment</option>
        
        
</select>
<br><br>

    	<input name="package" type="hidden"  placeholder="Sender Number" style="width:100%" value="">	





<label> TrxID:  (বিকা-রকেট-নগদ এ পে করার পর SMS এ যে TrxID পেযেছেন)</label><br>


    	<input name="trx_id" type="text"  placeholder="TrxID/Money Recpt Number"  required="" >	<br>
			
			


<label> যে নম্বর থেকে পে করেছেন (শুধু  মাত্র বিকাশ/রকেট/নগদের জন্য)</label><br>
    	<input name="sender_number" type="number"  placeholder="Sender Number" style="width:100%" minlength="11">	
			



<button type="submit" class="btn btn-default" style="width:100%; background:silver; font-size:130%">Confirm & Submit</button>
							</form>



</div>
        



       
</div>


</div>
                  
                  
    

              </div>
              <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
@endif

</div>





                </ul>
              </div>
            
    
  </section>
  </div>
  
  </div>
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  
  


 
<div class="mob_add">
    
    
    
    

    
    
    
    
    
    
     <div style="height:40px; width:100%; top:0; position:fixed; float:left; z-index:19999; border:2px solid white;  border:0px;">

 <section id="menu"style="padding:5px;" >
    

           
       <a href="#" style="float:left;    margin-top:4px; margin-left:5px;"> 
             
             
             
             
                
  
  <!-- Sidebar -->
  
  
  
  
  
  @if (!empty(Auth::check()))
<div class="w3-sidebar w3-bar-block w3-collapse w3-card w3-animate-left" style="width:80%; margin-left:-5px;" id="mySidebar">
    
      <button class="w3-bar-item w3-button w3-large w3-hide-large" onclick="w3_close()" style="margin-left:110%"><i class="fa fa-arrow-circle-left" aria-hidden="true" style="font-size:200%"></i>

  
  <style>
       .container{
       	height: 100%;
       	align-content: center;
       }

       .image_outer_container{
       	margin-top: auto;
       	margin-bottom: auto;
       	border-radius: 50%;
       	position: relative;
       }

       .image_inner_container{
       	border-radius: 50%;
       	padding: 5px;
        background: #833ab4; 
        background: -webkit-linear-gradient(to bottom, #fcb045, #fd1d1d, #833ab4); 
        background: linear-gradient(to bottom, #fcb045, #fd1d1d, #833ab4);
       }
       .image_inner_container img{
       	height: 80px;
       	width: 80px;
       	border-radius: 50%;
       	text-align:center;
       	border: 5px solid white;
       }

       .image_outer_container .green_icon{
         background-color: #4cd137;
         position: absolute;
         right: 30px;
         bottom: 10px;
         height: 30px;
         width: 30px;
         border:5px solid white;
         border-radius: 50%;
       }
  </style>
  
  
  
</button>



  <div class="container" style="margin-left:70px; margin-top:-40px">
		<div class="d-flex justify-content-center h-100" >
			<div class="image_outer_container">
				<div class="image_inner_container">
					<img src="https://d1csarkz8obe9u.cloudfront.net/posterpreviews/profile-design-template-4c23db68ba79c4186fbd258aa06f48b3_screen.jpg?ts=1581063859">
				</div>
			</div>
		</div>
		
	
	</div>
  
  	<h4 style="text-align:center;margin-left:70px">
		    <?php
		    $user_id = Auth::user()->name;
		    $user_id2 = Auth::user()->phone;
		    ?>
		    {{$user_id}} <br>
{{$user_id2}}</h4>
  
  
  
  

  
  
  
  
  
    <a href="/my-account" class="w3-bar-item w3-button">
      <i class="fa fa-user" aria-hidden="true" style="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; My Profile</a>
      	
  
  
  <a href="/" class="w3-bar-item w3-button">
      <i class="fa fa-shopping-cart" aria-hidden="true" style="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; View Shopping</a>
      	
      	
  <a href="/orders" class="w3-bar-item w3-button">
      <i class="fa fa-shopping-bag" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; 
      View orders</a>
      
      
      
      
     
      
      
  <a href="/my_generation" class="w3-bar-item w3-button">  <i class="fa fa-users" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; My Team <span style="color:blue">({{$total_allr}})</span></a>
      	
    
    
    
      	<?php
      	 $main_w=Auth::user()->id;
      	$total_cash_wallet_w=DB::table("ac_main")->where('user_id', $main_w)->sum("amount");
      	?>  	
      	
      	
<!--    <a href="/my_l" class="w3-bar-item w3-button">  <i class="fa fa-money" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp;My Wallet <span style="color:blue"> ({{$total_cash_wallet_w}})</span></a>-->
      	
      	
      	
      	
      	


      	
  <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Referral Bonus <span style="color:blue">({{$total_shop_wallet_r1+$total_shop_wallet_r2}})</span></a>
      	     	
      	

      	
    <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Genenation Bonus <span style="color:blue">({{$total_shop_wallet_r1b+$total_shop_wallet_r2b}})</span></a>
      	
      	
      	
<!--    	Sales Bonus=15 !-->
      	
      	
          <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Sales Bonus <span style="color:blue">({{$total_shop_wallet_r15+$total_shop_wallet_r25}})</span></a>
      		
      	
      
 <!--    	1% return Bonus=১00 !-->     
      
          <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Daily Return<span style="color:blue">({{$total_shop_wallet_r100+$total_shop_wallet_r200}})</span></a>
      		  	
      	
      	
<!--    	Monthly Slary Bonus=16 !-->     
           	
      	
           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Monthly Salary <span style="color:blue">({{$total_shop_wallet_r16+$total_shop_wallet_r16}})</span></a> 	
      	
    
                 	   	      	
           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Rank-Reward <span style="color:blue">({{$total_shop_wallet_r17+$total_shop_wallet_r17}})</span></a> 	    	     	
      	
      	
    	      	 
   <!--    	File Fund Bonus=18 !-->     
            	
      	           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Life Fund <span style="color:blue">({{$total_shop_wallet_r18+$total_shop_wallet_r18}})</span></a> 	    	     	
      	
      	
      	
           	
      	      	           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Shopping Balance <span style="color:red"> ( {{$total_shop_wallet_w}})</span></a> 		
      	
      	
      	
      	
      	
          	      	           <a href="#" class="w3-bar-item w3-button">  <i class="fa fa-square-o" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Total Cash Balance <span style="color:red">({{$total_cash_wallet_w}})</span></a> 	
      	  	
      	
      	
        <a href="#" class="w3-bar-item w3-button" data-toggle="modal" data-target="#modal-lg2">  <i class="fa fa-money" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp;Add Fund </a>
      	

      	
      	
      	
      	  <a href="/my_w_mobile" class="w3-bar-item w3-button">  <i class="fa fa-exchange" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Fund Transfar</a>
    
      	
      	

      	
      	

      	
      	
      	
      	      	
          	  <a href="/my_l" class="w3-bar-item w3-button">  <i class="fa fa-th-large" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Statment</a>	
      	
      	
      	
      	
      	
      	
 <a href="/my_w" class="w3-bar-item w3-button">  <i class="fa fa-credit-card" aria-hidden="true" sstyle="font-size:120%; color:blue; "></i>
      	&nbsp; 	&nbsp; Withdraw </a>
      	
      	
    
      	

      	
      	
     <a href="/my_generation" class="w3-bar-item w3-button">  <i class="fa fa-users" aria-hidden="true" sstyle="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; + New Registration</a>
      	

      

  <a href="/logout" class="w3-bar-item w3-button;" style="color:red">
      <i class="fa fa-sign-out" aria-hidden="true" style="font-size:120%; color:red; "></i>
      	&nbsp; 	&nbsp; Logout</a>
      	
      	
      	<br>
      	<br>      	<br>
      	<br>
      		
</div>





      	





   <div class="modal fade" id="modal-lg2" style="z-index:9999999; width:110%">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">

              <div class="modal-body">


<div class="row" style="margin-bottom:100px">

					<div class="col-md-12">


<?php

$results12 = DB::select('select * from banners where id = :id', ['id' => 12]);
$results13 = DB::select('select * from banners where id = :id', ['id' => 13]); 
$results14 = DB::select('select * from banners where id = :id', ['id' => 14]);

;?>


   @foreach($results12 as $t12)
     <?php 
        $bkash=$t12->image;   
        
     ;?>
@endforeach










@foreach($results13 as $t13)
     <?php 
        $rocket=$t13->image;     
     ;?>
@endforeach

@foreach($results14 as $t14)
     <?php 
        $nagad=$t14->image;     
     ;?>
@endforeach





 <div>


<span style="color:blue"><b>পেমেন্ট পদ্ধতিঃ </b><br></span>
বিকাশ নম্বর: {{$bkash}} (পার্সনাল)।<br>
রকেট নম্বর: {{$rocket}} (পার্সনাল)।<br>
নগদ নম্বর: {{$nagad}} (পার্সনাল)।<br>


<span style="color:blue"><b>নোটঃ </b><br></span>
বিকাশ/রকেট/নগদে পে করলে নিচের বক্স TrxID লিখুন। যদি ক্যাশ পেমেন্ট হয়, তাহলে প্রাপ্ত মানি রিসিপ্ট নম্বর লিখতে হবে।
					        
					    </div>









<div class="aa-myaccount-register" style="background:#EAEDED; padding:10px; border-radius:8px; margin-top:10px">



			<form id="account_Form" class="aa-login-form" name="accountForm" action="{{ url('/my_ggbdt') }}" method="post">
<!--			<form id="account_Form" class="aa-login-form" name="accountForm" action="{{ url('/joining_payment') }}" method="post">
-->								@csrf
	
	
															
							
	<h3 style="color:blue; text-align:center">Payment Information:</h3>	



    	<input name="amount" type="number"  placeholder=" Amount" min="200" required="" >	<br><br>


<select name="payment_method" style="width:100%; padding:6px;" required>
                       <option value="">Payment Method</option>

        <option value="bKash">bKash</option>
        <option value="Rockate">Rockate</option>
        <option value="Nagod">Nagod</option>
        <option value="Bank_Payment">Bank Payment</option>
        
        <option value="Cash_Payment">Cash Payment</option>
        
        
</select>
<br><br>

    	<input name="package" type="hidden"  placeholder="Sender Number" style="width:100%" value="">	





<label> TrxID:  (বিকা-রকেট-নগদ এ পে করার পর SMS এ যে TrxID পেযেছেন)</label><br>


    	<input name="trx_id" type="text"  placeholder="TrxID/Money Recpt Number"  required="" >	<br>
			
			


<label> যে নম্বর থেকে পে করেছেন (শুধু  মাত্র বিকাশ/রকেট/নগদের জন্য)</label><br>
    	<input name="sender_number" type="number"  placeholder="Sender Number" style="width:100%" minlength="11">	
			



<button type="submit" class="btn btn-default" style="width:100%; background:silver; font-size:130%">Confirm & Submit</button>
							</form>



</div>
        



       
</div>


</div>
                  
                  
    

              </div>
              <div class="modal-footer justify-content-between">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
	
	
	
	
	
	
	
	
	
@else











<div class="w3-sidebar w3-bar-block w3-collapse w3-card w3-animate-left" style="width:80%; margin-left:-5px;" id="mySidebar">
    
      <button class="w3-bar-item w3-button w3-large w3-hide-large" onclick="w3_close()" style="margin-left:110%"><i class="fa fa-arrow-circle-left" aria-hidden="true" style="font-size:200%"></i>

  
  <style>
       .container{
       	height: 100%;
       	align-content: center;
       }

       .image_outer_container{
       	margin-top: auto;
       	margin-bottom: auto;
       	border-radius: 50%;
       	position: relative;
       }

       .image_inner_container{
       	border-radius: 50%;
       	padding: 5px;
        background: #833ab4; 
        background: -webkit-linear-gradient(to bottom, #fcb045, #fd1d1d, #833ab4); 
        background: linear-gradient(to bottom, #fcb045, #fd1d1d, #833ab4);
       }
       .image_inner_container img{
       	height: 80px;
       	width: 80px;
       	border-radius: 50%;
       	text-align:center;
       	border: 5px solid white;
       }

       .image_outer_container .green_icon{
         background-color: #4cd137;
         position: absolute;
         right: 30px;
         bottom: 10px;
         height: 30px;
         width: 30px;
         border:5px solid white;
         border-radius: 50%;
       }
  </style>
  
  
  
</button>



  <div class="container" style="margin-left:70px; margin-top:-40px">
		<div class="d-flex justify-content-center h-100" >
			<div class="image_outer_container">
				<div class="image_inner_container">
					<img src="https://d1csarkz8obe9u.cloudfront.net/posterpreviews/profile-design-template-4c23db68ba79c4186fbd258aa06f48b3_screen.jpg?ts=1581063859">
				</div>
			</div>
		</div>
		
	
	</div>
  

  
  
  
  
  
  <a href="/login-registerj" class="w3-bar-item w3-button">
      <i class="fa fa-lock" aria-hidden="true" style="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Login</a>
      	
      	



 <a href="/login-register" class="w3-bar-item w3-button">
      <i class="fa fa-user" aria-hidden="true" style="font-size:120%; color:black; "></i>
      	&nbsp; 	&nbsp; Signup</a>



</div>
@endif 
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
             
              <div class=""style="width:100px; float:left; ">
  <button class="w3-butjon w3-eal w3-xlarge"  onclick="w3_open()" >☰</button>
</div>    
             
             
             
         <script>
function w3_open() {
    
    
    
  document.getElementById("mySidebar").style.display = "block";
}

function w3_close() {
  document.getElementById("mySidebar").style.display = "none";
}
</script>    
             
             
               <!-- <span id="sidebarCollapse22" style="color:white; display:black; padding:50px 4px";>
                                <i class="fa fa-bars" aria-hidden="true" ></i>
                                <span>Menu</span>
                            </span>-->
            
            </a>
            
            
       
            
           
            
             <div style="float:left; width:50%;">
                <form action="{{ url('/search') }}" method="post">
                    
                                        @csrf

                  <input type="text" name="search" id="" placeholder="Search product" required="" style="height:27px; width:72%; border-radius:2px; background:white;  border: 1px solid #ccc;
">
                  <button type="submit" style="height:28px; margin-left:-5px"><span class="fa fa-search" style="padding: 0px 0px"></span></button>
                </form>
              </div>
            
            
            
                                                 <a href=" {{url('/')}} "><img src="{{url('/')}}/assets/admin/img/banners/<?php echo $image7;?>" alt="logo img" style="float:right; height: 30px; max-width:70px; border-radius:4px"></a>

            
            
            
         
            
    
  </section>
  </div> 
  
  
  
   
  </div>

  
  
  
  
  
  
  </div>
