@extends('layouts.temp2.master')
@section('content')








	@include('layouts.temp2.nav')
  












<section id="do_action aa-myaccount" >
  <div class="container" style="padding-top:100px">
      
      
      
                     @if (Session::has('message_success'))
                      
                                  <h4 style="color:green; margin-top:150px; padding:50px 50px; text-align:center"> {{ session('message_success') }} </h4>

                                 @endif
      
      
   
   
   
      <?php
$results12 = DB::select('select * from banners where id = :id', ['id' => 12]);
$results13 = DB::select('select * from banners where id = :id', ['id' => 13]);
$results14 = DB::select('select * from banners where id = :id', ['id' => 14]);
$results22 = DB::select('select * from banners where id = :id', ['id' => 22]);


    ;?>        
          
          
@foreach($results12 as $t12)
     <?php 
       $h12=$t12->image;     
     ;?>
@endforeach

@foreach($results13 as $t13)
     <?php 
         $h13=$t13->image;     
     ;?>
@endforeach
   
 
 @foreach($results14 as $t14)
     <?php 
        $h14=$t14->image;     
     ;?>
@endforeach
     
   
      
 @foreach($results22 as $t22)
     <?php 
        $h22=$t22->image;     
     ;?>
@endforeach
     
      
      
      
      
        @if (Session::has('bKash'))
                      
                                  
                                  <h4 style="color:green; margin-top:150px; padding:50px 50px; text-align:center">
                                      <span style="font-size:130%">Order Place Successfull!! </span>
                                      
                                      
                                   
                                      </h4>


                                 @endif
      
      
        @if (Session::has('Rocket'))
                      
                                   
                                  <h4 style="color:green; margin-top:150px; padding:50px 50px; text-align:center">
                                      <span style="font-size:130%">Order Place Successfull!! </span>
                                      
                                      
                                   
                                      </h4>

                                 @endif
      
        @if (Session::has('Nagad'))
                      
                                   
                                  <h4 style="color:green; margin-top:150px; padding:50px 50px; text-align:center">
                                      <span style="font-size:130%">Order Place Successfull!! </span>
                                      
                                    
                                      </h4>

                                 @endif
      
              <a href="{{url('/my-account')}}">    <h3 style="color:blue; padding:10px 5px; text-align:right;" > < Back to Dashboard  </h3></a>

<h3 style="color:black; padding:10px 50px; text-align:center"> All Product (Common Sotre): </h3>
<h4 style="color:red;  text-align:center"> (প্রাইজ সহ কোন কিছু এডিট করতে হলে নিজস্ব স্টোরে এ্যাড করার পর করা যাবে) </h4>






<link rel="stylesheet" type="text/css" href="http://cdn.datatables.net/1.10.12/css/jquery.dataTables.min.css">
<script type="text/javascript" src="http://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>


    <script type="text/javascript">$(document).ready(function(){
    $('#myTable').DataTablee();
});</script>

                <table border="1" cellpadding="0" cellspacing="0" id="myTablee" class="display">          
                <thead>
              <tr>
                  <th>Product ID</th>
                  
                  <th>Category</th>
                  <th>Name</th>
                  <th>Details</th>
                  <th>Actions</th>
              </tr>
          </thead>
          <tbody>

<?php



            $orders=DB::table('products')->get();


;?>




            @foreach ($orders as $order)
            
                               
              <tr>
                  <td>{{$order->id}}</td>
                  <td>{{$order->category_id}}</td>
                  
                    <td><img src="{{url('/')}}/assets/admin/img/products/large/{{$order->image}}" style="width:50px"><br>{{$order->product_name}}</td>
                   <td>{{$order->description}}</td>
                  
                  <td> Add my Store </td>

              </tr>
            @endforeach


          </tbody>
   
      </table>

  </div>
</section><!--/#do_action-->

@endsection


<?php
  Session::forget('order_id');
  Session::forget('total');
?>
