@extends('layouts.temp2.master')
@section('content')
	@include('layouts.temp2.nav')



<?php

$nid=Auth::user()->nid;
$auth_id=Auth::user()->id;
$up_line_id=Auth::user()->up_line_id;




$rank=Auth::user()->rank;
$affiliate_block=Auth::user()->affiliate_block;


	$business_count=DB::table('shopks')->where('owner_user_id',$nid)->count();


$results12 = DB::select('select * from banners where id = :id', ['id' => 12]);
$results13 = DB::select('select * from banners where id = :id', ['id' => 13]); 
$results14 = DB::select('select * from banners where id = :id', ['id' => 14]);


$payment_check = DB::select('select * from ac_join where user_id = :user_id', ['user_id' => $auth_id]);




?>

 @foreach($results12 as $t12)
     <?php 
        $bkash=$t12->image;   
        
     ;?>
@endforeach




 @foreach($payment_check as $pc)
     <?php 
        $payment_status=$pc->status;     
        $pin=$pc->trx_id;     
     ;?>
@endforeach






@foreach($results13 as $t13)
     <?php 
        $rocket=$t13->image;     
     ;?>
@endforeach

@foreach($results14 as $t14)
     <?php 
        $nagad=$t14->image;     
     ;?>
@endforeach


   

	<section id="aa-myaccount" style="margin-top:0px;">

		<div class="container"  style="width:90%; margin:auto;">
			@if (Session::has('message_success'))
							 <div class="control-group">
									 <div class="controls">
											 <div class="alert alert-success">

													 <strong style="color:#000">{{ session('message_success') }}</strong>

											 </div>
										 </div>
							 </div>
			 @endif
			 @if (Session::has('message_error'))
								<div class="control-group">
										<div class="controls">
												<div class="alert alert-danger">

														<strong style="color:#000">{{ session('message_error') }}</strong>

												</div>
											</div>
								</div>
				@endif
				
				
					@if (Session::has('message_s'))
					<a href="{{ url('/my-account') }}">

								<div class="control-group">
										<div class="controls">
												<div class="alert alert-danger" style="background:green; text-align:center">
														<strong style="color:white;text-align:center">{{ session('message_s') }}<br></strong>
<h3 style="color:white">Go to DashBoard >></h3>
												</div>
											</div>
								</div></a>
				@endif	
		
				
				
				
				
				
		
			<div class="row" style="margin-bottom:100px">

					<div class="col-md-6 col-md-offset-3">
					    
	
	

		
					    

	
	
	
	
	
	
	
	
	
	

					    	@if (Session::has('message_b'))
								<div class="control-group">
										<div class="controls">
												<div class="alert alert-success" style="background:green; color:white; text-align:center ">

														<strong style="color:white;text-align:center">{{ session('message_b) }}</strong>

												</div>
											</div>
								</div>
				@endif	
				
					    
					    
					    

		
		
		
		
		

	
					    

					    
					    
					    <h3 style="color:black; text-align:center; border:1px solid black; border-radius:5px; padding:4px">Create Your Own Store/Shop/Business </h3>
					    
	
	
	
	
	
	
					    
					    <div>
					  <p style="color:black; text-align:center; font-size:110%"><b> আপনার যদি একজন উদ্যোক্ত হয়ে থাকেন, তাহলে আমাদের এখানে আপনি শপ/স্টোর ওপেন করে আপনার প্রডাক্টসমূহ বিক্রয় করতে পারবেন। (ট্রেড লাইসেন্স থাকা বাধ্যতামূলক) </b><br></p>
					        
					    </div>
					    
					    
					    
					    
					    
						<div class="aa-myaccount-register" style="background:#EAEDED; padding:10px; border-radius:8px; margin-top:10px">



			<form id="account_Form" class="aa-login-form" name="accountForm" action="{{ url('/') }}/create2" method="post" enctype="multipart/form-data">
								@csrf
	
	
	 <?php
                    $aa_dist=DB::table('all_dist')->orderby('dist_name','ASC')->get();
                   ;?>
           														
							
	<h3 style="color:blue; text-align:left"> আপনার জেলা নির্বাচন করুন </h3>	

<select name="dis" style="width:100%; padding:6px;" id="mySelect" onchange="ChangeCarList()"  required>
                       <option value="">Select Distrct</option>

@foreach ($aa_dist as $dist)
    <option value="{{$dist->dist_code}}">{{$dist->dist_name}}</option>
    @endforeach</select>
<br>
							
	<h3 style="color:blue; text-align:left"> আপনার থানা/উপজেলা  নির্বাচন করুন</h3>	

<select name="ps" id="sm14" style="width:100%; padding:6px;" required>
                       <option value="">Select P.S/Thana</option>
  </select>

<br>


<label> আপনার নিজনেস/ প্রতিষ্ঠানের নাম</label><br>



    	<input name="business_name" type="text"  placeholder="Your Business Name" style="width:100%" minlength="3">	
			
			
		<?       $user_id = Auth::user()->id;
 ?>	
			

	<input name="oid" type="hidden"  placeholder="ii" style="width:100%" value="{{ $user_id}}">	
			

<label>বিজনেস/প্রতিষ্ঠানের ঠিকানা: </label><br>



    	<input name="address" type="text"  placeholder=" Business Address" style="width:100%" minlength="3">	
				
		




<label> ট্রেড লাইসেন্স সংযুক্ত করুন :</label><br>
<input type="file" name="file">



<br>

<label>লগো :(পরবর্তীতে পরিবর্তন করা যাবে) </label><br>
<input type="file" name="file2">








<button type="submit" class="btn btn-default" style="width:100%; background:silver; font-size:130%; margin-top:100px">Submit Information</button>
							</form>



</div>







































				</div>

			
			
			
			</div>
			
		


			
			
			
		</div>








	</section>


@endsection

 
<?php
$urla=$_SERVER['SERVER_NAME'];
?>


<script type="text/javascript">
function ChangeCarList(){
    var x = document.getElementById("mySelect").value;
     $.ajax({
            url:'https://{{$urla}}/app/search_ps.php?dis_id='+x,
                        success:function(response){
                        $('#sm14').html(response);
                        }
                        
        });
}
</script>


