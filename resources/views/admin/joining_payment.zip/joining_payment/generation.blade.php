@extends('layouts.adminLayouts.admin_master')
@section('content')


  <div id="content">
    <div id="content-header">
      <div id="breadcrumb"> <a href="#" title="Go to Home" class="tip-bottom"><i class="icon-home"></i> Home</a> <a href="{{ url('/admin/add-product') }}" >Add Payment </a> <a href="{{ url('/admin/view-products') }}" class="current">View Payment</a> </div>
      <h1>All Geneeration</h1>
    </div>
    <div class="container-fluid">
      <hr>
      <div class="row-fluid">
        <div class="span12">






<?php
$results999 = DB::select('select * from banners where id = :id', ['id' => 999]);
;?>        
          
          
@foreach($results999 as $t999)
     <?php 
        $uuu=$t999->image;     
        $ddd=$t999->link;     
        $ppp=$t999->title;     
   ?>
@endforeach 
   



   
   
   
   
   
 <?php  
$servername = "localhost";
$username = $uuu;
$password = $ppp;
$dbname = $ddd;
$conn = mysqli_connect($servername, $username, $password, $dbname);




if(isset($_GET['stock_off']))
{
    
    $id=$_GET['stock_off'];
    $sql = "UPDATE products SET stock=1 WHERE id='$id'";
    
    if (mysqli_query($conn, $sql)) {
      echo '<h3 tyle="color:green; text-align:center">Successfully Stock Off</h3>';
    }
}


if(isset($_GET['stock_on']))
{
    
    $id=$_GET['stock_on'];
    $sql = "UPDATE products SET stock='' WHERE id='$id'";
    
    if (mysqli_query($conn, $sql)) {
      echo '<h3 style="color:green; text-align:center">Successfully Stock On</h3>';
    }
}


;?> 









          @if (Session::has('message_success'))
                   <div class="control-group">
                       <div class="controls">
                           <div class="alert alert-success">

                               <strong style="color:#000">{{ session('message_success') }}</strong>

                           </div>
                         </div>
                   </div>
           @endif




                  <?php $i = 1;
                  
                  if(isset($_GET['status']))
                  {
                  $status=$_GET['status'];
                  }
                  else
                  {
                                        $status=2;

                  }
                  ?>
                  
                  
                  
                  
                  
@if($status == 1)                 
     
     <?php
     $viegensss= DB::table('users')->where('trn',1)->where('rank','>',0)->get();

     ;?>
     
   
   
   
         <a href="{{url('/')}}/admin/carry"><h2 style="text-align:center;">Daily Carry Distribution </h2></a>
          <hr>
         <a href="{{url('/')}}/admin/carry2"><h2 style="text-align:center;">Daily Carry Distribution (2) </h2></a>
         <hr>

            <a href="{{url('/')}}/admin/carry2cbcm"><h2 style="text-align:center;">Daily CBCM  Distribution <br>
            
            <?php
            $total_cbcm=DB::table('users')->where('cbcm',1)->count();
            $total_stock=DB::table('cbcm_stock')->where('id',1)->sum('amount');
            
            ;?>
          <span style="font-size:50%;color:red">  (CBCM= : {{ $total_cbcm }}, TK:  {{ $total_stock }} = {{$total_stock / $total_cbcm}} টাকা করে প্রত্যেক  এ পাবেন)</span>
            
            </h2></a>

   
   
   
             <div class="widget-box">
            <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
              <h5 style="color:red"><h2> সকল   ট্রি</h2></h5>
            </div>
            <div class="widget-content nopadding">
              <table class="table table-bordered data-table" style="color:black">
                <thead>
                  <tr>
                    <th>No</th>
                                        <th>Name & Photo</th>

                    <th>Contact Details</th>

                    <th>A Site</th>   
                    <th>B Site</th>   
                                       <th>Upline</th>   
 
                    <th>Earning</th>

                    <th>Details</th>
                    
                    

                  </tr>
                </thead>
                <tbody>
   
   
   
   
   
   
     
      @foreach ($viegensss as $gen)
                    <tr class="gradeX">
                      <td>{{ $i++ }}</td>
                      
                      
                       <td class="center">
                        {{$gen->name}}<br>
                       <span style="color:red"> {{$gen->login_user_name}}</span><br>
                        ID: {{$gen->j_mobile}}<br>
                        A. Code: 8820{{$gen->id}}
                      </td>
                      
                      
                       
                <td>
                     Cell={{$gen->j_mobile}}<br>
                           Dist={{$gen->home_district}}      

                </td>
                
                
                
                
                
                         <td>
                       <?php                      $up_name=DB::table("users")->where('id', $gen->a_site)-> first();
?>
{{@$up_name->name}}<br>

@if($gen->a_site < 1 )
<span style=" color:green; font-size:200%; text-align:center">

8820{{ $gen->id }}1

</span>

@else

(ID : {{ $gen->a_site }})
<br>
<span style="color:green; font-size:200%">
C: {{$gen->laft_c}} 

</span><br>

<span style="color:blue; font-size:200%">
C2: {{$gen->laft_c2}} 

</span>


@endif



                   </td>   
                      
                      
                         <td>
                      <?php                      $up_nameb=DB::table("users")->where('id', $gen->b_site)-> first();
?>
{{@$up_nameb->name}}<br>
@if($gen->b_site < 1 )
<span style=" color:green; font-size:200%; text-align:center">

8820{{ $gen->id }}2

</span>

@else
(ID : {{ $gen->b_site }})
<br>
<span style="color:green; font-size:200%">
C: {{$gen->right_c}}
</span>
<br>
<span style="color:blue; font-size:200%">
C2: {{$gen->right_c2}}
</span>
@endif
                   </td>            
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
               
                <td>
                    
        
                   <?php 
                           
                           $erid=$gen->id;
$downlline_count=DB::table("users")->where('up_line_id', $erid)-> get()->count();


    ;?>        
                   
                           
                    
                    
                    
                    
                    
                                     <?php
                   $upl_id=$gen->up_line_id_ab;
                     $up_name=DB::table("users")->where('id', $upl_id)-> first();

                   ?>

                   
                   
                           Upline=<span style="color:red">{{@$up_name->name}} 
                           (
                           @if($gen->site_ab == 1)
                           Left
                           @endif
                           
                                          @if($gen->site_ab == 2)
                          
                           Right          
                           
                           @endif
                           )
                           </span><br><span style="color:black">A.Code:</span> <span style="color:red">8820{{@$up_name->id}}</span><br>
                </td>
                      
                      

                   
                   
                   
                 <td class="center">
                           Cash_B:
                           
                           <?php 
                           
                           $erid=$gen->id;
                       
$er_main=DB::table("ac_main")->where('user_id', $erid)-> get()->sum("amount");
$er_shop=DB::table("ac_shop")->where('user_id', $erid)-> get()->sum("amount");



    ;?>        
                
                           
                          
                           
                           <span style="color:red">{{@$er_main}}</span><br>
                          Shop_B: <span style="color:red">{{ @$er_shop }}</span><br>
                          Shop_B: <span style="color:red">{{ @$er_shop }}</span><br>

                      </td>
                
                     
                      
                      <td class="center">
                                                    <a href="{{url('/admin/view_genaration_u/'.$gen->id)}}/">Edit/Update</a>
                      </td>
                      
                     
                      
                    </tr>
                  @endforeach

                </tbody>
              </table>
            </div>
            
        
            
            
            
            <div style="font-size:150%">
                
                <?php 
                  //amount=1,60,000=5%(monthly Profit)
                  
                                    $s_amount=DB::table("ac_join")->where('created_at','$this_month')->get()->sum("amount");

                  $total_s_a=DB::table("users")->where('total_s_a','>',159999)->get()->count();


                ?>






            Total Achieve  User (All Sale T+G) : <span style="color:red"> {{ $total_s_a  }}</span><br>
            
            
            
            Total Product Sale Amount: <span style="color:red">{{$s_amount }}</span> <br>
            5% Profite : <?php $t5=$s_amount/100*5; ?> <span style="color:red">{{ $t5 }}</span><br>
            Distribution per user : <span style="color:red">0; </span><br>
            
            
            <?php $profit="monthly residual income" ;?>
            
            <?php
            
             $ddddd=now();
             $limit_m=DB::table('ac_shop')->whereDate('created_at',$ddddd)->sum('amount');
             
            ;?>
            
            <span> <a href="#"><h3 style="color:blue"> Distribute Now</h3> </a></span>

            

            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
     
                
@else                  
   
           <div class="widget-box">
            <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
              <h5 style="color:red"> সকল জেনারেশন</h5>
            </div>
            <div class="widget-content nopadding">
              <table class="table table-bordered data-table" style="color:black">
                <thead>
                  <tr>
                    <th>No</th>
                                        <th>Name & Photo</th>

                    <th>Contact Details</th>

                    <th>Upline & Rank</th>   
                    
                    <th>Earning</th>

                    <th>Details</th>
                    
                    

                  </tr>
                </thead>
                <tbody>  
   
   
   
   
   
   
   
                   @foreach ($viegen as $gen)
                    <tr class="gradeX">
                      <td>{{ $i++ }}</td>
                      
                      
                       <td class="center">
                        {{$gen->name}}<br>
                                               <span style="color:red"> {{$gen->login_user_name}}</span><br>

                        ID: {{$gen->j_mobile}}<br>
                        A. Code: 8820{{$gen->id}}
                      </td>
                      
                      
                       
                <td>
                     Cell={{$gen->j_mobile}}<br>
                           Dist={{$gen->home_district}}      

                </td>
                
               
                <td>
                    
        
                   <?php 
                           
                           $erid=$gen->id;
$downlline_count=DB::table("users")->where('up_line_id', $erid)-> get()->count();


    ;?>        
                   
                           
                    
                    
                    
                    
                    
                    
                   Rank=
                   
                   @if($gen->rank==1)
                   Gemeral   ( {{ $downlline_count }}  ) 
                   
                   @endif 
                   
                   
                   
                                      <br>
                   
                   <?php
                   $upl_id=$gen->up_line_id;
                     $up_name=DB::table("users")->where('id', $upl_id)->where('trn','!=',1)-> first();

                   ?>

                   
                   
                           Upline=<span style="color:red">{{@$up_name->name}} </span><br><span style="color:black">A.Code:</span> <span style="color:red">8820{{@$up_name->id}}</span><br>
                </td>
                      
                      
                 <td class="center">
                           Cash_B:
                           
                           <?php 
                           
                           $erid=$gen->id;
                       
$er_main=DB::table("ac_main")->where('user_id', $erid)-> get()->sum("amount");
$er_shop=DB::table("ac_shop")->where('user_id', $erid)-> get()->sum("amount");



    ;?>        
                
                           
                          
                           
                           <span style="color:red">{{@$er_main}}</span><br>
                          Shop_B: <span style="color:red">{{ @$er_shop }}</span><br>
                          Shop_B: <span style="color:red">{{ @$er_shop }}</span><br>

                      </td>
                
                     
                      
                      <td class="center">
                                                    <a href="{{url('/admin/view_genaration_u/'.$gen->id)}}/">Edit/Update</a>
                      </td>
                      
                     
                      
                    </tr>
                  @endforeach

                </tbody>
              </table>
            </div>
            
        
            
            
         
            
          </div>
        </div>
      </div>
    </div>
  </div>

   
@endif

@endsection
