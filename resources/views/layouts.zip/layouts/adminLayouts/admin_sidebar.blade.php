<?php $url = url()->current(); ?>
<!--sidebar-menu-->
<div id="sidebar"><a href="{{ url('/admin/dashboard') }}" class="visible-phone"><i class="fa fa-bars" aria-hidden="true"></i>
 Admin <i class="fa fa-angle-double-down" style="color:white"aria-hidden="true" ></i></a>
  <ul>
      
      
      

      
      
    <li <?php if (preg_match("/dashboard/i", $url)){ ?> class="active" <?php } ?>><a href="{{ url('/admin/dashboard') }}" style="color:white"><i class="fa fa-line-chart" aria-hidden="true"></i>
  <span>Dashboard</span></a> </li>
    
    
    
   <li> <a href="{{ url('/admin/view-orders') }}" style="color:white"><i class="fa fa-th-list" aria-hidden="true"></i> <span>Orders</span></a>

    </li> 
    
    	<?php
		
        $md = DB::table('banners')
       ->where(['id' => 1008])
        ->first();
        
        
                $ml_md = DB::table('banners')
       ->where(['id' => 1010])
        ->first();
        
        
      ;?>
        
         @if(!empty($md->image))
    
    
  <li> <a href="{{ url('/admin/view-coupons2') }}"style="color:white"><i class="fa fa-medkit" aria-hidden="true"></i>
<span>Medicine Orders</span></a>
    </li> 
    @endif
      <li class="submenu"> <a href="#" style="color:white"><i class="fa fa-archive" aria-hidden="true"></i>
 <span>Products</span> <i class="fa fa-angle-double-down" style="color:white"aria-hidden="true" ></i>
</a>
      <ul>
        <li><a href="{{ url('/admin/view-products') }}"><i class="fa fa-eye" aria-hidden="true"></i>
 View Products</a></li>
        <li><a href="{{ url('/admin/add-product') }}"><i class="fa fa-plus-square" aria-hidden="true"></i>
 Add Product</a></li>
                <li><a href="{{ url('/admin/view-products2') }}"><i class="fa fa-check" aria-hidden="true"></i>
Product Approved</a></li>

        
              @if(!empty($md->image))
   
        <li><a href="{{ url('/admin/add-productm') }}"><i class="fa fa-medkit" aria-hidden="true"></i>
Add Medicine</a></li>
                <li><a href="{{ url('/admin/view-productsm') }}"><i class="fa fa-eye" aria-hidden="true"></i>
View Medicine</a></li>

        
@endif
      </ul>
      
      
      
      
      
    </li>  
    
    
  
  
    
    
    <li class="submenu"> <a href="#" style="color:white"><i class="fa fa-calendar" aria-hidden="true"></i> <span>Categories</span> <i class="fa fa-angle-double-down" style="color:white"aria-hidden="true" ></i></a>
      <ul >
        <li><a href="{{ url('/admin/view-categories') }}">View Category</a></li>
        <li><a href="{{ url('/admin/add-category') }}">Add Category</a></li>
        <li><a href="{{ url('/admin/add-categoryc') }}">Add Child Category</a></li>

      </ul>
    </li>



 









<li class="submenu"> <a href="#" style="color:white"><i class="fa fa-user" aria-hidden="true"></i>
 <span>User/Merchant</span></a>
      <ul>
        <li><a href="{{ url('/admin/view-coupons') }}">All User</a></li>
        
                 @if($ml_md->image == 1)

        <li><a href="{{ url('/admin/view-couponsm') }}">All Merchant</a></li>
      @endif

      </ul>
    </li> 
    
    
    
    <li class="submenu"> <a href="#" style="color:white"><i class="fa fa-cog" aria-hidden="true"></i>
 <span>Site Setting</span></a>
      <ul>
        <li><a href="{{ url('/admin/view-banners') }}">Update Setting</a></li>

      </ul>
    </li>
   
   
   
     
        <li class="submenu"> <a href="#" style="color:white"><i class="fa fa-th-large" aria-hidden="true"></i>

 <span>Brands</span></a>
      <ul>
        <li><a href="{{ url('/admin/view-categories2') }}">View Brands</a></li>
        <li><a href="{{ url('/admin/add-category2') }}">Add Brands</a></li>

      </ul>
    </li>  
    
    
    
    
    <li> <a href="{{ url('/admin/view_payment2') }}" style="color:white"><i class="fa fa-credit-card" aria-hidden="true"></i>
 <span>Withwraw Approve</span></a>
    </li>
   
    
    
    
    
    
    
    
    
    
   <!-- 
    
    <li style="background:green; color:white"> <a href="{{ url('/admin/view_payment') }}" style="color:white"><i class="icon icon-th-list" style="color:white"></i> <span>Payment Approve</span></a>
    </li>
    
    
    
    
    
    
    
    
    
    
    
    
        <li style="background:green; color:white"> <a href="{{ url('/admin/pin_payment') }}" style="color:white"><i class="icon icon-th-list" style="color:white"></i> <span>Generate PIN</span></a>
    </li>
   
   
    
    <li style="background:green; color:white"> <a href="{{ url('/admin/view_payment_r') }}" style="color:white"><i class="icon icon-th-list" style="color:white"></i> <span>R-Perchance Approve</span></a>
    </li>

 <li style="background:green; color:white"> <a href="{{ url('/admin/view_genaration') }}" style="color:white"><i class="icon icon-th-list" style="color:white"></i> <span>Generation View</span></a>
    </li>

   
   
 
    <li style="background:green; color:white"> <a href="{{ url('/admin/view_payment_g') }}" style="color:white"><i class="icon icon-th-list" style="color:white"></i> <span>Gift Card</span></a>
    </li>



    <li style="background:green; color:white"> <a href="#" style="color:white"><i class="icon icon-th-list" style="color:white"></i> <span>All Transaction</span></a>
    </li>


    <li style="background:green; color:white"> <a href="#" style="color:white"><i class="icon icon-th-list" style="color:white"></i> <span>Total Summary</span></a>
    </li>




-->



   <li > <a href="{{ url('https://www.tawk.to/') }}" target="_blank"><i class="icon icon-th-list"></i> <span>Live Chat</span></a>

    </li>


    <li > <a href="http://ictsky.com/service/sms" target="_blank"><i class="icon icon-th-list"></i> <span>Send SMS</span></a>

    </li>




<li > <a href="http://ictsky.com/service/marketing" target="_blank"><i class="icon icon-th-list"></i> <span>Advertise/Marketing</span></a>

    </li>



 <li > <a href="http://ictsky.com/renew" target="_blank"><i class="icon icon-th-list"></i> <span>Domain/Hosting Renew</span></a>

    </li>


 <li > <a href="http://ictsky.com/update" target="_blank"><i class="icon icon-th-list"></i> <span>Update/Upgrade</span></a>

    </li>    

 <li > <a href="http://ictsky.com/service" target="_blank"><i class="icon icon-th-list"></i> <span>Developer Help Line</span></a>

    </li>





  </ul>
</div>
<!--sidebar-menu-->
