<!--Footer-part-->

<div class="row-fluid">
  <div id="footer" class="span12"> 2020 &copy;</div>
</div>

<!--end-Footer-part-->
