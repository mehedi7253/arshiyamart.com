@extends('layouts.temp2.master')
@section('content')
  <!-- menu -->

@include('layouts.temp2.nav')




<style>
    .button {
  width: 48px;
  height: 48px;
  cursor: pointer;
  &:hover {
    fill: white;
  }
}

.defs {
  position: absolute;
  top: -9999px;
  left: -9999px;
}


.buttons {
  padding: 1rem;
  background: #f06d06;
  float: left;
}

body {
  padding: 1rem;
}
</style>




  <section id="aa-product">

    <div class="container">


    

      <div class="row" >

        <div class="col-md-12">
          <div class="row" style="height:850px; ">
                        	<!--<div class="col-md-3"></div>-->








 <div class="h-video" style="position:relative; width:78%; height:420px; margin-top:50px; margin-left:11%">
<?php
        	$m_9=DB::table('banners')->where('id',9)->first();
                ;?> 
          		<iframe id="video"  width="100%" height="100%" src="https://www.youtube.com/embed/pFg_eTanFPQ?enablejsapi=1" title="YouTube video player"
          		frameborder="0" allow="accelerometer; autoplay; clipboard-write; 
          		encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
</div>



 <div class="home-video" style="position: absolute;  width:86%; height:480px; margin-top:-440px; margin-left:7%">
  <img src="/app/tv2.png" style="width:100%; height:530px">
</div>
 		
 	
 	
 	
 

 <svg class="defs">
  <defs>
    <path id="pause-button-shape" d="M24,0C10.745,0,0,10.745,0,24s10.745,24,24,24s24-10.745,24-24S37.255,0,24,0z M21,33.064c0,2.201-1.688,4-3.75,4
s-3.75-1.799-3.75-4V14.934c0-2.199,1.688-4,3.75-4s3.75,1.801,3.75,4V33.064z M34.5,33.064c0,2.201-1.688,4-3.75,4
s-3.75-1.799-3.75-4V14.934c0-2.199,1.688-4,3.75-4s3.75,1.801,3.75,4V33.064z" />
    <path id="play-button-shape" d="M24,0C10.745,0,0,10.745,0,24s10.745,24,24,24s24-10.745,24-24S37.255,0,24,0z M31.672,26.828l-9.344,9.344
C20.771,37.729,19.5,37.2,19.5,35V13c0-2.2,1.271-2.729,2.828-1.172l9.344,9.344C33.229,22.729,33.229,25.271,31.672,26.828z" />
  </defs>
</svg>



<div class="buttons">
  <!-- if we needed to change height/width we could use viewBox here -->
  <svg class="button" id="play-button">
    <use xlink:href="#play-button-shape">
  </svg>
  <svg class="button" id="pause-button">
    <use xlink:href="#pause-button-shape">
  </svg>
</div>
 	
          	
          	
          
          </div>


        </div>


      </div>
      
      
      
      
      
      
      
      
      
      
      
      
      
      
      
    
      
      
      
      
      
      <script>
// https://developers.google.com/youtube/iframe_api_reference

// global variable for the player
var player;

// this function gets called when API is ready to use
function onYouTubePlayerAPIReady() {
  // create the global player from the specific iframe (#video)
  player = new YT.Player("video", {
    events: {
      // call this function when player is ready to use
      onReady: onPlayerReady
    }
  });
}

function onPlayerReady(event) {
  // bind events
  var playButton = document.getElementById("play-button");
  playButton.addEventListener("click", function () {
    player.playVideo();
  });

  var pauseButton = document.getElementById("pause-button");
  pauseButton.addEventListener("click", function () {
    player.pauseVideo();
  });
}

// Inject YouTube API script
var tag = document.createElement("script");
tag.src = "//www.youtube.com/player_api";
var firstScriptTag = document.getElementsByTagName("script")[0];
firstScriptTag.parentNode.insertBefore(tag, firstScriptTag);
</script>





    
     </div>
    </section>     	


@endsection